<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Absen extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model("Absen_model");
        $this->load->helper('url');
        $this->load->model('User_model');
        $this->load->model('Temp_model');
        $this->load->library('form_validation');
        $this->load->model("Login_model");
        if($this->Login_model->isNotLogin()) redirect(site_url('admin/login'));

    }

public function index(){
        $temp = $this->Temp_model;
        $validation = $this->form_validation;
        $validation->set_rules($temp->rules());

        if ($validation->run()) {
            $temp->save();
            $this->session->set_flashdata('success', 'Data Berhasil Dikirim');
        }
        $this->load->view("admin/Absen/view.php");
}

public function harian(){
    // $temp = $this->Temp_model;
    $temp = $this->Absen_model;
    $validation = $this->form_validation;
    $validation->set_rules($temp->rules());

    if ($validation->run()) {
        $temp->save();
        $this->session->set_flashdata('success', 'Data Berhasil Dikirim');
    }
    $this->load->view("admin/Absen/harian.php");
}

public function batch(){
    // $temp = $this->Temp_model;
    $temp = $this->Absen_model;
    $validation = $this->form_validation;
    $validation->set_rules($temp->rules());

    if ($validation->run()) {
        $temp->savebatch();
        $this->session->set_flashdata('success', 'Data Berhasil Dikirim');
    }
    $this->load->view("admin/Absen/batch.php");
}

  public function list(){

        $data["respon"] = $this->Absen_model->getRecords();
        $this->load->view("admin/Absen/absen_view.php", $data);
  }

  public function approve(){

    $data["temp_form"] = $this->Absen_model->getByHadir();
        $this->load->view("admin/Absen/approval", $data);
  }
  public function detail_approve($no = null, $bln = null){
    if (!isset($no)) redirect('absen/batch');
    if (!isset($bln)) redirect('absen/batch');
    $data["temp_form"] = $this->Absen_model->getByHadirId($no);
    $data["temp"] = $this->Absen_model->getByHadirDetail($no,$bln);
        $this->load->view("admin/Absen/detail_approval", $data);
  }

}