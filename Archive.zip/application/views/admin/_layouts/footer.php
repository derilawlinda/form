                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">&copy 2020 &middot; PT. Patra Drilling Contractor</div>
                            <div>
                                <a href="https://pertamina-pdc.com">Home</a>
                                &middot;
                                <a href="https://item.pertamina-pdc.network">IT-eM</a>
                            </div>
                        </div>
                    </div>